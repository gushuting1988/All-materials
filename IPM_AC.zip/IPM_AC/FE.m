function Egy = FE(kpa,phi,dx,n)

   
    Egy = 0;

    phi(n+1) = phi(1);
    
    phi_x(1:n) = (phi(2:n+1)-phi(1:n))/dx;

    f = (phi(1:n).^2.0-1.0).^2.0/4;
    
    Egy = 0.5*kpa*kpa*dot(phi_x,phi_x)*dx + sum(f)*dx;


end