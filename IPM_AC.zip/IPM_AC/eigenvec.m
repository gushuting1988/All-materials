function v = eigenvec(kpa, dx, N, phi_k)
    % Input: kpa, dx, N, phi_k(1:N)
    % Output: v(1:N)
    
    rkx = kpa*kpa/dx/dx;
    a = -rkx*dx;    
    k1(1:3) = [1 2 N]';
    for j=2:N-1
        k1(3*(j-1)+1:3*j) = [j-1,j,j+1];
    end
    j=N;
    k1(3*(j-1)+1:3*j) = [1 N-1 N];
    k1 = k1';

    for j=1:N
        k2(3*(j-1)+1:3*j) = j;
    end
    k2 = k2';
    
    k3(1) = (3*phi_k(1)^2-1)*dx-2*a;
    k3(2) = a;
    k3(3) = a;
    for j=2:N-1
        k3(3*(j-1)+1:3*j) = [a,dx*(3*phi_k(j)^2-1)-2*a,a];
    end
    j=N;
    k3(3*(j-1)+1:3*j) = [a,a,dx*(3*phi_k(j)^2-1)-2*a];
    k3 = k3';

    H = sparse(k1,k2,k3); 
    H = H/dx;
    
    H_G = 0;
    H_tilte = H - H_G;
    H_hat = H_tilte;
    
    [V,D] = eigs(H_hat,6,'sr');  
      fprintf('%22.16f',D(1,1))
      fprintf('%22.16f',D(2,2))
      fprintf('%18.10f',D(3,3))
      fprintf('%18.10f',D(4,4))
      fprintf('%18.10f',D(5,5))
      fprintf('%18.10f',D(6,6))
             fprintf('\n')
%       pause
      
    v = V(:,1);   % to be modified!!!
norm_v = sqrt(dot(v,v)*dx);
v = v/norm_v;
     x = linspace(0,1,N+1);

end