% IMF_AC.m

clear;
kpa = 0.1;
N = 200;
tol = 1.e-12;
norm_err = 1.0e-5;
IterN = 10000;
beta = 2.0;

K = 0.66;
b = 4;

dt = 1.e-2;

dx = 1.0/N;
x = linspace(0,1,N+1);

kx(1:3) = [1 2 N]';
for j=2:N-1
    kx(3*(j-1)+1:3*j) = [j-1,j,j+1];
end
kx(3*(N-1)+1:3*N) = [1,N-1,N];
i=1;
for j=1:N
  ky(i:i+2) = j;
  i = i+3;
end
ky = ky';
kz(1:3) = [-2 1 1]';
for j=2:N-1
    kz(3*(j-1)+1:3*j) = [1 -2 1];
end
kz(3*(N-1)+1:3*N) = [1 1 -2];
 
A = sparse(kx,ky,kz);
A = A/dx/dx;    
 
load phi0.mat

phi_k = phi0(1:N);

v = eigenvec(kpa, dx, N, phi_k);

h = figure;plot(x,phi0,'k--','LineWidth',3),axis([0 1 -1 1.2]), ...
    xlabel('$x$','interpreter','Latex'), ylabel('$\phi(x)$', 'interpreter','Latex');


grad_F = -kpa*kpa*A*phi_k + phi_k.^3.0 - phi_k;   % get force under L2 metric
norm_grad_F(1) = sqrt(dot(grad_F,grad_F)*dx);    % get L2 norm
F(1) = FE(kpa,phi_k,dx,N);

fprintf(' %18.12f \n ',norm_grad_F(1))
    

Total_num = 0;
%for i=1:2

i = 0;
while(norm_grad_F(i+1)> tol)
    i = i+1;
    
    phi_n = phi_k;
    
    phi_hat = phi_k + dot(phi_n-phi_k,v)*dx*v;
    L(1) = FE(kpa,phi_n,dx,N) - beta*FE(kpa,phi_hat,dx,N) ...
            + K*sum(abs(phi_n-phi_k)).^b*dx;
    
    grad_F = -kpa*kpa*A*phi_n + phi_n.^3.0 - phi_n; 
    grad_F_hat = -kpa*kpa*A*phi_hat + phi_hat.^3.0 - phi_hat;
    gradL = grad_F - beta*dot(v,grad_F_hat)*dx*v ...
            + b*K*(abs(phi_n-phi_k)).^(b-2.0).*(phi_n-phi_k);
    norm_grad_L(1) = sqrt(dot(gradL,gradL)*dx);
   
    for j = 1:IterN
        
        Total_num = Total_num +1;
        phi_n = L_dynamic_AC_beta(A, v, dt, kpa, phi_n, phi_k, N, dx, beta, K, b); 
        
    end
        grad_F = -kpa*kpa*A*phi_n + phi_n.^3.0 - phi_n;   % get force under L2 metric
        norm_grad_F(i+1) = sqrt(dot(grad_F, grad_F)*dx);
        
        fprintf( '%3i  | ',i)
        fprintf(' %18.12f \n ',norm_grad_F(i+1))

    phi_k = phi_n;
    v = eigenvec(kpa, dx, N, phi_k);   

end
    

phi_k(N+1) = phi_k(1);


hold on; plot(x,phi_k,'k','LineWidth',3)

% hold on; plot(x,density(:,26),'r','LineWidth',2)    % string method result
% legend('initial state','transition state','SM result')
%figure;
% plot(x,phi_k,'LineWidth',2),axis([0 1 -1 1.2]),xlabel('$x$','interpreter','latex'), ylabel('$\phi(x)$','interpreter','latex');
% %legend('initial state','transition state')
% set(gca,'FontSize',16)
% set(get(gca,'xlabel'),'FontSize',20), set(get(gca,'ylabel'),'FontSize',20)
% %set(get(gca,'title'),'FontSize',16)

% saveas(h,'saddle_IMF_new','fig')
% save('AC_saddle3_IMF')

FE = FE(kpa,phi_k,dx,N);
disp(FE)


 figure;

 semilogy(norm_grad_F, 'k-','LineWidth',3)


