function phi_n_new = L_dynamic_AC_beta(A, v, dt, kpa, phi_n, phi_k, N, dx, beta, K, b)

    phi_tilte = phi_k + dot(v,phi_n-phi_k)*dx*v;
    
    phi_mid = phi_tilte.^3.0;
    phi_mid = beta* dot(v,phi_mid)*dx*v;
    
    f1 = phi_mid - phi_n.^3.0 + phi_n;

     f2 = beta*kpa*kpa*dot(v,A*phi_tilte)*dx*v + beta*v*dot(v,phi_n)*dx;
    
    f = dt*(f1-f2) + phi_n - b*K*dt*(abs(phi_n-phi_k)).^(b-2.0).*(phi_n-phi_k);  % RHS
    
    I = eye(N);
    
     B = I - dt*kpa*kpa*A;
    phi_n_new = B\f;
    

end