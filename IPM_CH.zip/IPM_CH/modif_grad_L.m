
function grad_L_L2 = modif_grad_L(kpa, A, phi_n_new, phi_n, phi_k, v, dx, P, M, b)

    phi_tilte_n = phi_k + v*dot(v,phi_n-phi_k)*dx;
    phi_tilte_n_new = phi_k + v*dot(v,phi_n_new-phi_k)*dx;
    
    grad_L_L2_vec = -kpa*kpa*A*phi_n_new + 2.0*phi_n_new + 2.0*v*dot(v,phi_tilte_n_new)*dx + phi_n.^3.0 ...
        - 3.0*phi_n - 2.0*v*dot(v,phi_tilte_n.^3.0)*dx + 2.0*kpa*kpa*v*dot(v,A*phi_tilte_n)*dx;
    
    grad_L_L2_vec = grad_L_L2_vec + b*M*(abs(phi_n-phi_k)).^(b-2.0).*(phi_n-phi_k);
    
    grad_L_L2_vec = P*grad_L_L2_vec;

    grad_L_L2 = sqrt(dot(grad_L_L2_vec,grad_L_L2_vec)*dx);

end