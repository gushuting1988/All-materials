
function L_phi = L_A_C(phi, phi_k, v, kpa, dx, N)
     
        phi_tilte = phi_k + dot(v,phi-phi_k)*dx*v;
        
        for i=1:N
            iL = i-1;
            iR = i+1;
            if(iL<1)
                iL = iL+N;
            end
            if(iR>N)
                iR = iR-N;
            end
            phi_tilte_x(i) = 0.5*(phi_tilte(iR)-phi_tilte(iL))/dx;
        end
        phi_tilte_x = phi_tilte_x';
            
       for i=1:N
           iL = i-1;
           iR = i+1;
           if(iL<1)
               iL = iL+N;
           end
           if(iR>N)
               iR = iR-N;
           end
           phi_x(i) = 0.5*(phi(iR)-phi(iL))/dx;
       end
       phi_x = phi_x';
       
       f_phi = 0.25*(phi.^2.0-1.0).^2.0;
       f_phi_tilte = 0.25*( phi_tilte.^2.0-1.0).^2.0;
       
       l = 0.5*kpa*kpa*phi_x.^2.0 + f_phi - kpa*kpa*phi_tilte_x.^2.0 - 2.0*f_phi_tilte;
       
       L_phi = (sum(l))*dx;

end