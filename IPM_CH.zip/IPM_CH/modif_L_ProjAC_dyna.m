function phi_n_new = modif_L_ProjAC_dyna(A, v, dt, kpa, phi_n, phi_k, N, dx, P, M, b)

    phi_tilte = phi_k + dot(v,phi_n-phi_k)*dx*v;
    
    phi_mid = phi_tilte.^3.0;
    phi_mid = 2.0* dot(v,phi_mid)*dx*v;
    
    f1 = phi_mid - phi_n.^3.0 + 3.0*phi_n;
    f2 = 2.*kpa*kpa*v*dot(v,A*phi_tilte)*dx;
    
    f = dt*P*(f1-f2) + phi_n;
    
    f = f - b*dt*M*P*((abs(phi_n-phi_k)).^(b-2.0).*(phi_n-phi_k));
    
    I = eye(N);
    C = 2*dt*P*dx;
    Cv = C*v;
    
    B = I - dt*kpa*kpa*P*A + 2.*dt*P;
    
    B = B+Cv*v';
    phi_n_new = B\f;

end