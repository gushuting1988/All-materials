%% Modified IMF for AC eq

clear;
kpa = 0.04;
N = 100;
iter_N = 1000;
tol = 1.e-12;
norm_err = 1.0e-8;
M = 10;
b = 4;


dt = 0.1;

dx = 1.0/N;
x = linspace(0,1,N+1);

kx(1:3) = [1 2 N]';
for j=2:N-1
    kx(3*(j-1)+1:3*j) = [j-1,j,j+1];
end
kx(3*(N-1)+1:3*N) = [1,N-1,N];
 
i=1;
for j=1:N
  ky(i:i+2) = j;
  i = i+3;
end
ky = ky';
 
kz(1:3) = [-2 1 1]';
for j=2:N-1
    kz(3*(j-1)+1:3*j) = [1 -2 1];
end
kz(3*(N-1)+1:3*N) = [1 1 -2];
 
A = sparse(kx,ky,kz);
A = A/dx/dx;    % A\in R^{N*N}

% Introduce the projection P
P = eye(N);
Id_vec(1:N) = 1.; Id_vec = Id_vec';
P = P - Id_vec*Id_vec'/N;
 
load res_sm.mat;
m = sum(res_sm(1:N))*dx;

% % initialization
 phi0 = 0.5*cos(2*pi*x);
phi0 = phi0';


m0 = sum(phi0(1:N))*dx;
if m0<1e-8  % almost 0
    disp('Initial mass is almost 0, mass plus m.')
    phi0 = phi0 + m; 
else  % not 0, change it from m0 to m
    disp('Initial mass is not 0, divided by m0 and multiply m.')
    phi0 = phi0/m0*m;
end


phi_k = phi0(1:N); 


h = figure;plot(x,phi0,'k--','LineWidth',3),axis([0 1 -1 1.2]), ...
    xlabel('$x$','interpreter','Latex'), ylabel('$\phi(x)$', 'interpreter','Latex');
% legend('initial state \phi^{(0)}')
set(gca,'FontSize',16)
set(get(gca,'xlabel'),'FontSize',20), set(get(gca,'ylabel'),'FontSize',20)
set(get(gca,'title'),'FontSize',14)


% rotation step. to be modified!!!!!!
 v = eigenvec_AC_new(kpa, dx, N, phi_k, P, 1);    % v\in R^{N*N}

v_err = sqrt(dot(v-P*v,v-P*v)*dx); 

grad_F_phik = -kpa*kpa*A*phi_k + phi_k.^3.0 - phi_k ;   % get force under L2 metric
norm_grad_F(1) = sqrt(dot(P*grad_F_phik,P*grad_F_phik)*dx);    % get L2 norm (NOTE: shall introduce P here!)
norm_grad_F_A(1) = sqrt(dot(A*grad_F_phik,A*grad_F_phik)*dx);    % get L2 norm (NOTE: shall introduce P here!)

fprintf(' %28.22f | %28.22f |%12.8f \n ',norm_grad_F(1), norm_grad_F_A(1), v_err)

phi_n = phi_k;

total_num = 0;

i = 0;
while(norm_grad_F(i+1)> tol)
    i = i+1;

    norm_grad_L(1) = grad_L(kpa, A, phi_n, phi_n, phi_k, v, dx, P);
    L(1) = L_A_C(phi_n, phi_k, v, kpa, dx, N);
    t(1) = 0.;
   for j=1:iter_N
   
        t(j+1) = t(j) + dt;
        total_num = total_num +1;
        phi_n_new = modif_L_ProjAC_dyna(A, v, dt, kpa, phi_n, phi_k, N, dx, P, M, b); % this is right!
   
        L(j+1) = modif_L_AC(phi_n_new, phi_k, v, kpa, dx, N, M, b);
        norm_grad_L(j+1) = modif_grad_L(kpa, A, phi_n_new, phi_n, phi_k, v, dx, P, M, b);
        norm_dist(j) = sqrt(dot(phi_n-phi_n_new, phi_n-phi_n_new)*dx);
        
        phi_n = phi_n_new;
     
   end

    phi_k = phi_n;   
    
    v = eigenvec_AC_new(kpa, dx, N, phi_k, P,i);
    v_err = sqrt(dot(v-P*v,v-P*v)*dx); 
    
    grad_F = -kpa*kpa*A*phi_k + phi_k.^3.0 - phi_k ;   % get force under L2 metric
    norm_grad_F(i+1) = sqrt(dot(P*grad_F, P*grad_F)*dx);
    norm_grad_F_A(i+1) = sqrt(dot(A*grad_F, A*grad_F)*dx);
    
    fprintf( '%3i  | ',i)
   fprintf(' %28.22f | %28.22f | %12.8f \n ',norm_grad_F(i+1), norm_grad_F_A(i+1), v_err)
      
end

phi_final = phi_k;
phi_k(N+1) = phi_k(1);

hold on; plot(x,phi_k,'k','LineWidth',3)
hold on; plot(x,res_sm,'r','LineWidth',2)    % string method result
legend('initial state','transition state','SM result')

size_phi = size(norm_grad_F);
x_axis = linspace(1,total_num,size_phi(2));
y_axis = linspace(1,size_phi(2),size_phi(2));

figure; semilogy(y_axis,norm_grad_F,'LineWidth',2),xlabel('outer cycle $k$','interpreter','latex'), ...
    ylabel('$\|\delta_\phi F(\phi^{(k)})\|_{L^2}$','interpreter','latex')
    title('convex result')
