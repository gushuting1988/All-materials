function v = eigenvec_AC_new(kpa, dx, N, phi_k, P, kk)
    % Input: kpa, dx, N, phi_k(1:N)
    % Output: v(1:N)
    
    rkx = kpa*kpa/dx/dx;
    a = -rkx*dx;
    
    k1(1:3) = [1 2 N]';
    for j=2:N-1
        k1(3*(j-1)+1:3*j) = [j-1,j,j+1];
    end
    j=N;
    k1(3*(j-1)+1:3*j) = [1 N-1 N];
    k1 = k1';

    for j=1:N
        k2(3*(j-1)+1:3*j) = j;
    end
    k2 = k2';
    
    k3(1) = (3*phi_k(1)^2-1)*dx-2*a;
    k3(2) = a;
    k3(3) = a;
    for j=2:N-1
        k3(3*(j-1)+1:3*j) = [a,dx*(3*phi_k(j)^2-1)-2*a,a];
    end
    j=N;
    k3(3*(j-1)+1:3*j) = [a,a,dx*(3*phi_k(j)^2-1)-2*a];
    k3 = k3';

    H = sparse(k1,k2,k3);   % Hessian matrix
    H = H/dx;
    
    H_G = 0;
    H_tilte = H - H_G;
    H_hat = P*H_tilte*P;    % if H_hat = P*H_tilte, also right!
    

    [V,d] = eig(full(H_hat));   
    for i = 1:N
        dd(i) = d(i,i); 
    end    
    [dum,ind] = sort(dd);
    
    m = 3;
    for index = 1:m
        for i = 1:m-index+1
            if(dum(index)>dum(index+i))
                t = dum(index+i);
                dum(index+i) = dum(index);
                dum(index) = t;
                tmp = ind(index+i);
                ind(index+i) = ind(index);
                ind(index) = tmp;
            end
        end
    end

    phi_k(N+1) = phi_k(1);
    phix = (phi_k(2:N+1)-phi_k(1:N))/dx;
    phix = phix / sqrt(dot(phix,phix)*dx);

    i = 1;
    v = V(:,ind(i));
    cosx = dot(v,phix)/sqrt(dot(v,v))/sqrt(dot(phix,phix));
    if abs(cosx)>0.95 %& force<0.01*f0
        for j = i:N-1
            V(:,ind(j)) = V(:,ind(j+1));
            dum(j) = dum(j+1);
        end
    else
        i = i+1;
        v = V(:,ind(i));
        cosx = dot(v,phix)/sqrt(dot(v,v))/sqrt(dot(phix,phix));
        if abs(cosx)>0.95 
            for j = i:N-1
                V(:,ind(j)) = V(:,ind(j+1));
                dum(j) = dum(j+1);
            end
        end
    end

    index = 1;
    v = V(:,ind(index));
    int_v = sum(v(:))*dx;  
    while abs(int_v) > 1.e-6
        index = index + 1;
        v = V(:,ind(index));
        int_v = sum(v(:))*dx;
        disp('yes')
    end
    
   norm_v = sqrt(dot(v,v)*dx);
   v = v/norm_v;

end